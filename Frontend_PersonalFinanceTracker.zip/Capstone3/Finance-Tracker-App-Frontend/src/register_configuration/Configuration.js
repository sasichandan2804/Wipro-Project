export const SignUp = 'https://localhost:7137/api/Auth/SignUp';
export const SignIn = 'https://localhost:7137/api/Auth/SignIn';