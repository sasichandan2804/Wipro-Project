import axios from 'axios';
const AuthServices = {
  signUp: (data) => axios.post('https://localhost:7137/api/Auth/SignUp', data, false),
  signIn: (data) => axios.post('https://localhost:7137/api/Auth/SignIn', data, false),
};


export default AuthServices;

