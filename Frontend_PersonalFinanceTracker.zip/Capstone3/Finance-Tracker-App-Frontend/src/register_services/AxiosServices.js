
import axios from 'axios';
/*
const axios = require('axios').defaults

export default class AxiosServices {
  //url='http://localhost:3000/SignIn';
  post(url, data, isRequiredHeader = false, header) {
    return axios.post(url, data, isRequiredHeader && header)
  }
}
*/

const AxiosServices = {
  post: (url, data, isAuth = false) => axios.post(url, data),
};

export default AxiosServices;
