import { ActionCreaters } from "../app/expensesReducer";
export const GetExpenses=async(dispatch)=>{
    try{
        //api call
        const expenses=[
            {id:1,description:'Groceries', amount:50},
            {id:2,description:'Gas',amount:500},
            {id:3,description:'Electricity',amount:400},
        ];
        dispatch(ActionCreaters.setExpenses(expenses));
    }
    catch{
        console.log('Error!');
    }
}
export const NewExpense=async(dispatch,expense)=>{
    try{
        //api call
        dispatch(ActionCreaters.newExpense({id:20,description:expense.description,
        amount:expense.amount}));
    }
    catch{
        console.log("Error!");
    }
}

export const EditExpense = async (dispatch, expense) => {
    try {
        // api call
        
        dispatch(ActionCreaters.editExpense(expense));
    } catch {
        console.log('Error!');
    }
}

export const DeleteExpense = async (dispatch, expense) => {
    try {
        // api call
        
        dispatch(ActionCreaters.deleteExpense(expense));
    } catch {
        console.log('Error!');
    }
}