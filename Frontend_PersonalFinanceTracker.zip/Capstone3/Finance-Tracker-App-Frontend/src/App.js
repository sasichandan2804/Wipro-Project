import {BrowserRouter as Router,Routes,Route} from 'react-router-dom';
import SignUp from './register_components/SignUp';
import SignIn from './register_components/SignIn';
import Dashboard from './register_components/Dashboard';
function App(){
  return(
    <div className='App'>
      <Router>
        <Routes>
          <Route path='/' element={<SignUp />} />
          <Route path='/SignIn' element={<SignIn />} />
          <Route path='/Dashboard' element={<Dashboard />}/>
        </Routes>
      </Router>
    </div>
  );
}

export default App;
