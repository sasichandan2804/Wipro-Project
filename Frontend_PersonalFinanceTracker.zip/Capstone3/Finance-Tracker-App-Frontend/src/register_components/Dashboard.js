import React from "react";
import ExpenseForm from "../components/ExpenseForm";
import ExpenseList from "../components/ExpenseList";
import LogOut from "./Logout";
function Dashboard(){
    return(
        <div style={{width:'60%',margin:'auto'}}>
            <h1 style={{color:"#a47864",textAlign:"center"}}>Personal Finance Tracker</h1><br />
            <h3>New Expense</h3><br />
            <ExpenseForm />
            <hr style={{border:'1px solid grey'}} />
            <h3>Your Expenses</h3><br />
            <ExpenseList />
            <LogOut />
        </div>
    );
}
export default Dashboard;
    

