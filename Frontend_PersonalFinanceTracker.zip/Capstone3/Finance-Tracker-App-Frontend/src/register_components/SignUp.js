import React,{useState} from "react"; 
import AuthServices from "../register_services/AuthServices";
import '../register_configuration/signUp.scss';
import TextField from '@mui/material/TextField';
import Button from "@mui/material/Button";
import Snackbar from '@mui/material/Snackbar'
import IconButton from '@mui/material/IconButton'
import CloseIcon from "@mui/icons-material/Close";
import { useNavigate} from "react-router-dom";


const SignUp = () => {
  const navigate = useNavigate(); // ✅ Use hook directly
  //const authServices = new AuthServices();
  // State Variables
  const [userName, setUserName] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const [userNameFlag, setUserNameFlag] = useState(false);
  const [passwordFlag, setPasswordFlag] = useState(false);
  const [confirmPasswordFlag, setConfirmPasswordFlag] = useState(false);

  const [open, setOpen] = useState(false);
  const [message, setMessage] = useState("");

  // Close Snackbar
  const handleClose = (event, reason) => {
    if (reason === "clickaway") return;
    setOpen(false);
  };

  // Validation Function
  const checkValidity = () => {
    setUserNameFlag(userName === "");
    setPasswordFlag(password === "");
    setConfirmPasswordFlag(confirmPassword === "");
    return userName!=="" && password!=="" && confirmPassword!=="";
  };

  // Handle Submit
  const handleSubmit = async () => {
    if (!checkValidity()) {
      setOpen(true);
      setMessage("Please Fill Required Fields");
      return;
    }
    checkValidity();
    if (userName && password && confirmPassword) {
      const data = {
        userName: userName,
        password: password,
        confirmPassword: confirmPassword,
        
      };

      try {
        const response = await AuthServices.signUp(data);
        if (response.data.isSuccess) {
          navigate("/SignIn"); // ✅ Navigate after success
        } else {
          setOpen(true);
          setMessage("Sign Up Failed");
        }
      } catch (error) {
        console.log("error:", error);
        setOpen(true);
        setMessage("Something Went Wrong");
      }
    } else {
      setOpen(true);
      setMessage("Please Fill Required Fields");
    }
  };

  // Navigate to Sign In Page
  const handleSignIn = () => {
    navigate("/SignIn");
  };

  return (
    
    <div className="SignUp-Container">
      
      <div className="SignUp-SubContainer">
        <div className="Header">Sign Up</div>
        <div className="Body">
          <form className="form">
            <TextField
              className="TextField"
              name="UserName"
              label="User Name"
              variant="outlined"
              size="small"
              error={userNameFlag}
              value={userName}
              onChange={(e) => setUserName(e.target.value)}
            />
            <TextField
              className="TextField"
              type="password"
              name="Password"
              label="Password"
              variant="outlined"
              size="small"
              error={passwordFlag}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            <TextField
              className="TextField"
              type="password"
              name="ConfirmPassword"
              label="Confirm Password"
              variant="outlined"
              size="small"
              error={confirmPasswordFlag}
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
            />
            
          </form>
        </div>
        <div className="Buttons">
          <Button className="Btn" color="primary" onClick={handleSignIn}>
            Sign In
          </Button>
          <Button className="Btn" variant="contained" color="primary" onClick={handleSubmit}>
            Sign Up
          </Button>
        </div>
      </div>
      <Snackbar
        anchorOrigin={{ vertical: "bottom", horizontal: "left" }}
        open={open}
        autoHideDuration={6000}
        onClose={handleClose}
        message={message}
        action={
          <>
            <Button color="secondary" size="small" onClick={handleClose}>
              UNDO
            </Button>
            <IconButton size="small" aria-label="close" color="inherit" onClick={handleClose}>
              <CloseIcon fontSize="small" />
            </IconButton>
          </>
        }
      />
    </div>
  );
};

export default SignUp;