import { useNavigate } from "react-router-dom";
const LogOut = () => {
    const navigate = useNavigate();

    const handleSubmit = (event) => {
        event.preventDefault(); // Prevents page reload
        // Perform form submission logic here (like sending data to a server)

        // Navigate to the home page
        navigate('/SignIn');
    };

    return (
        <div class="container d-flex justify-content-center">
            <button  onClick={handleSubmit}>LogOut</button>
        </div>
        
    );
};

export default LogOut;