import React,{useState} from "react"; 
import AuthServices from "../register_services/AuthServices";
import '../register_configuration/signUp.scss';
import TextField from '@mui/material/TextField';

import Button from "@mui/material/Button";

import Snackbar from '@mui/material/Snackbar'
import IconButton from '@mui/material/IconButton'
import CloseIcon from "@mui/icons-material/Close";
import { useNavigate } from "react-router-dom";




const SignIn = () => {
  const navigate = useNavigate(); // ✅ React Router hook for navigation
  //const authServices = new AuthServices();
  // ✅ State variables using useState
  const [userName, setUserName] = useState("");
  const [password, setPassword] = useState("");
  const [userNameFlag, setUserNameFlag] = useState(false);
  const [passwordFlag, setPasswordFlag] = useState(false);
  const [open, setOpen] = useState(false);
  const [message, setMessage] = useState("");

  // ✅ Snackbar close handler
  const handleClose = (event, reason) => {
    if (reason === "clickaway") return;
    setOpen(false);
  };

  // ✅ Input change handler
  const handleChange = (e) => {
    const { name, value } = e.target;
    if (name === "UserName") setUserName(value);
    if (name === "Password") setPassword(value);
  };

  // ✅ Navigate to Sign Up
  const handleSignUp = () => {
    navigate("/");
  };

  // ✅ Validate inputs
  const checkValidation = () => {
    setUserNameFlag(userName === "");
    setPasswordFlag(password === "");
    return userName !== "" && password !== "";
  };

  // ✅ Form submission (Sign In)
  const handleSubmit = async () => {
    if (!checkValidation()) {
      setOpen(true);
      setMessage("Please Fill Required Fields");
      return;
    }

    let data = {
      userName: userName,
      password: password,
    };

    try {
      const response = await AuthServices.signIn(data);
      console.log('data:',data);
      if (response.data.isSuccess) {
        navigate("/Dashboard"); // ✅ Redirect on successful login
      } else {
        setOpen(true);
        setMessage("Login Unsuccessful");
      }
    } catch (error) {
      console.log("error:", error);
      setOpen(true);
      setMessage("Something Went Wrong");
    }
  };

  return (
    <div className="SignUp-Container">
      <div className="SignUp-SubContainer">
        <div className="Header">Sign In</div>
        <div className="Body">
          <form className="form">
            <TextField
              className="TextField"
              name="UserName"
              label="User Name"
              variant="outlined"
              size="small"
              error={userNameFlag}
              value={userName}
              onChange={handleChange}
            />
            <TextField
              className="TextField"
              type="password"
              name="Password"
              label="Password"
              variant="outlined"
              size="small"
              error={passwordFlag}
              value={password}
              onChange={handleChange}
            />
          </form>
        </div>
        <div className="Buttons">
          <Button className="Btn" color="primary" onClick={handleSignUp}>
            Create New Account
          </Button>
          <Button className="Btn" variant="contained" color="primary" onClick={handleSubmit}>
            Sign In
          </Button>
        </div>
      </div>
      <Snackbar
        anchorOrigin={{ vertical: "bottom", horizontal: "left" }}
        open={open}
        autoHideDuration={6000}
        onClose={handleClose}
        message={message}
        action={
          <>
            <Button color="secondary" size="small" onClick={handleClose}>
              UNDO
            </Button>
            <IconButton size="small" aria-label="close" color="inherit" onClick={handleClose}>
              <CloseIcon fontSize="small" />
            </IconButton>
          </>
        }
      />
    </div>
  );
};

export default SignIn;